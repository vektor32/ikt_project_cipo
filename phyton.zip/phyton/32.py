class Cipo:
    def __init__(self, nev, marka, meret):
        self.__nev = nev
        self.__marka = marka
        self.__meret = meret

    def get_nev(self):
        return self.__nev
    
    def get_marka(self):
        return self.__marka
    
    def get_meret(self):
        return self.__meret

    def __str__(self):
        return f"{self.__nev} | {self.__marka} | {self.__meret}"

# A többi kód nem változik

def fajlbol_beolvas():
    cipok = []
    with open("cipo.txt", "r", encoding="utf-8") as file:
        for sor in file:
            adat = sor.strip().split("-")
            cipo = Cipo(adat[0], adat[1], int(adat[2]))  
            cipok.append(cipo)  
    return cipok

def leggyakoribb_marka(cipok):
    szamlalo = {}
    for cipo in cipok:
        szamlalo[cipo.get_marka()] = szamlalo.get(cipo.get_marka(), 0) + 1
    return max(szamlalo, key=szamlalo.get)

def legnagyobb_cipo(cipok):
    legnagyobb = cipok[0]
    for cipo in cipok:
        if cipo.get_meret() > legnagyobb.get_meret():
            legnagyobb = cipo
    return legnagyobb.get_nev(), legnagyobb.get_meret()

def fajlba_mentes(marka, legnagyobb_cipo):
    with open("legtobb_cipo.txt", "w", encoding="utf-8") as file:
        file.write(f"Legtöbb előforduló márka: {marka}\n")
    with open("legnagyobb_cipo.txt", "w", encoding="utf-8") as file:
        file.write(f"Legnagyobb cipő: {legnagyobb_cipo[0]}, Méret: {legnagyobb_cipo[1]}")

cipok = []
cipok = fajlbol_beolvas()

for _ in range(3):
    nev = input("Cipő neve: ")
    marka = input("Márkája: ").capitalize()
    meret = int(input("Mérete: "))
    cipok.append(Cipo(nev, marka, meret))

legtobb_marka = leggyakoribb_marka(cipok)
legnagyobb = legnagyobb_cipo(cipok)

fajlba_mentes(legtobb_marka, legnagyobb)

print(f"A legnagyobb cipő: {legnagyobb[0]}, Méret: {legnagyobb[1]}")
print(f"Legtöbb előforduló márka: {legtobb_marka}")
